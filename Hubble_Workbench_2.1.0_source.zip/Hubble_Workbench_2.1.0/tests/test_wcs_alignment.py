import tempfile
import unittest
from pathlib import Path

import numpy as np
from astropy.io import fits
from astropy.wcs import WCS

from hubble_workbench_app.fits_io import first_image_hdu, stack_fits_exposures, wcs_align_fits_channels
from hubble_workbench_app.image_processing import estimate_neutral_rgb_gains


class WcsAlignmentTests(unittest.TestCase):
    def test_first_image_hdu_merges_primary_metadata_with_science_wcs(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "jwst_style.fits"
            primary = fits.PrimaryHDU()
            primary.header["TELESCOP"] = "JWST"
            primary.header["INSTRUME"] = "NIRCAM"
            wcs = WCS(naxis=2)
            wcs.wcs.ctype = ["RA---TAN", "DEC--TAN"]
            wcs.wcs.crpix = [5.5, 5.5]
            wcs.wcs.crval = [10.0, 20.0]
            wcs.wcs.cdelt = [-0.001, 0.001]
            science = fits.ImageHDU(np.ones((10, 10), dtype=np.float32), header=wcs.to_header(), name="SCI")
            fits.HDUList([primary, science]).writeto(path)

            data, header = first_image_hdu(path)

            self.assertEqual(data.shape, (10, 10))
            self.assertEqual(header["TELESCOP"], "JWST")
            self.assertEqual(header["INSTRUME"], "NIRCAM")
            self.assertEqual(header["CTYPE1"], "RA---TAN")

    def test_neutral_balance_ignores_black_border_and_reduces_color_cast(self):
        image = np.zeros((20, 20, 3), dtype=np.float32)
        image[3:17, 3:17] = (0.20, 0.10, 0.05)
        image[8:12, 8:12] = (1.0, 0.8, 0.6)

        red, green, blue = estimate_neutral_rgb_gains(image)

        self.assertLess(red, green)
        self.assertLess(green, blue)
        self.assertGreaterEqual(red, 0.5)
        self.assertLessEqual(blue, 1.8)

    def write_fits(self, path, value, crval, shape=(10, 10)):
        wcs = WCS(naxis=2)
        wcs.wcs.ctype = ["RA---TAN", "DEC--TAN"]
        wcs.wcs.crpix = [(shape[1] + 1) / 2, (shape[0] + 1) / 2]
        wcs.wcs.crval = list(crval)
        wcs.wcs.cdelt = [-0.001, 0.001]
        fits.PrimaryHDU(np.full(shape, value, dtype=np.float32), header=wcs.to_header()).writeto(path)

    def test_aligns_shifted_channels_on_union_canvas_and_reports_overlap(self):
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            paths = [directory / f"channel_{index}.fits" for index in range(3)]
            self.write_fits(paths[0], 1, (10.000, 20.000))
            self.write_fits(paths[1], 2, (10.003, 20.000))
            self.write_fits(paths[2], 3, (10.006, 20.000))

            channels, headers, metadata = wcs_align_fits_channels(paths)

            self.assertEqual(len(channels), 3)
            self.assertTrue(all(channel.shape == channels[0].shape for channel in channels))
            self.assertGreater(channels[0].shape[1], 10)
            self.assertGreater(metadata["overlap_fraction"], 0)
            self.assertLess(metadata["overlap_fraction"], 1)
            self.assertIn("CTYPE1", headers[0])

    def test_alignment_preserves_channel_metadata_with_shared_wcs(self):
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            paths = [directory / f"metadata_{index}.fits" for index in range(2)]
            self.write_fits(paths[0], 1, (10.0, 20.0))
            self.write_fits(paths[1], 2, (10.002, 20.0))
            for index, path in enumerate(paths):
                with fits.open(path, mode="update") as hdul:
                    hdul[0].header["TELESCOP"] = "JWST"
                    hdul[0].header["INSTRUME"] = "MIRI"
                    hdul[0].header["FILTER"] = f"F{index + 1}000W"

            _channels, headers, _metadata = wcs_align_fits_channels(paths)

            self.assertEqual(headers[0]["TELESCOP"], "JWST")
            self.assertEqual(headers[0]["INSTRUME"], "MIRI")
            self.assertEqual(headers[0]["FILTER"], "F1000W")
            self.assertEqual(headers[1]["FILTER"], "F2000W")
            self.assertIn("CTYPE1", headers[0])

    def test_downsamples_excessive_union_canvas(self):
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            paths = [directory / f"channel_{index}.fits" for index in range(2)]
            self.write_fits(paths[0], 1, (10.0, 20.0))
            self.write_fits(paths[1], 2, (11.0, 20.0))
            channels, _headers, metadata = wcs_align_fits_channels(paths, max_output_pixels=100)
            self.assertGreater(metadata["pixel_scale_factor"], 1)
            self.assertLessEqual(channels[0].size, 100)

    def test_stacks_exposures_with_background_matching_and_artifact_rejection(self):
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            paths = [directory / f"exposure_{index}.fits" for index in range(3)]
            self.write_fits(paths[0], 1, (10.0, 20.0))
            self.write_fits(paths[1], 2, (10.0, 20.0))
            self.write_fits(paths[2], 3, (10.0, 20.0))
            with fits.open(paths[1], mode="update") as hdul:
                hdul[0].data[5, 5] = 1000
            output = directory / "stacked.fits"

            output_path, metadata = stack_fits_exposures(paths, output, weights=[1, 2, 1])

            self.assertTrue(output_path.exists())
            self.assertGreater(metadata["rejected_samples"], 0)
            with fits.open(output_path) as hdul:
                self.assertEqual(hdul[0].header["NSTACK"], 3)
                self.assertEqual(hdul[1].name, "COVERAGE")
                self.assertLess(hdul[0].data[5, 5], 10)

    def test_stack_matches_a_background_gradient_across_exposures(self):
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            first = directory / "first.fits"
            second = directory / "second.fits"
            self.write_fits(first, 10, (10.0, 20.0), shape=(30, 30))
            self.write_fits(second, 10, (10.0, 20.0), shape=(30, 30))
            with fits.open(second, mode="update") as hdul:
                hdul[0].data += np.linspace(-2, 2, 30, dtype=np.float32)[None, :]

            output_path, metadata = stack_fits_exposures([first, second], directory / "gradient.fits")

            self.assertNotEqual(metadata["background_planes"][1][1], 0.0)
            self.assertLess(metadata["background_plane_limits"][1][0], metadata["background_plane_limits"][1][1])
            with fits.open(output_path) as hdul:
                row = hdul[0].data[5].copy()
                self.assertLess(float(np.nanmax(row) - np.nanmin(row)), 0.3)

    def test_shared_stack_coverage_mode_keeps_only_full_exposure_overlap(self):
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            paths = [directory / f"shifted_{index}.fits" for index in range(2)]
            self.write_fits(paths[0], 1, (10.000, 20.000), shape=(30, 30))
            self.write_fits(paths[1], 1, (10.010, 20.000), shape=(30, 30))
            stacked, _metadata = stack_fits_exposures(paths, directory / "stacked.fits")

            full, _headers, full_metadata = wcs_align_fits_channels([stacked, stacked])
            shared, _headers, shared_metadata = wcs_align_fits_channels(
                [stacked, stacked], require_full_stack_coverage=True
            )

            self.assertEqual(full_metadata["stack_coverage_mode"], "full mosaic")
            self.assertEqual(shared_metadata["stack_coverage_mode"], "shared exposure overlap")
            self.assertLess(np.isfinite(shared[0]).sum(), np.isfinite(full[0]).sum())
            self.assertTrue(np.array_equal(np.isfinite(shared[0]), np.isfinite(shared[1])))


if __name__ == "__main__":
    unittest.main()
